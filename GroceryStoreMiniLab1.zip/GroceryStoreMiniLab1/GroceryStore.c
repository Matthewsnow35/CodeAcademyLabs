#include <stdio.h>

int main() {
  int appleQuantity = 23;
  int appleReviewDisplay = 82.5;
  float applePrice = 1.49;
  float applereview = 82.5;
  const char appleLocation = 'F';

  appleReview = appleReviewDisplay;


// Put all your code above this and if you declare your variables using the given names and types there is no need to change any of the code below.
printf("An apple costs: $%.2f, there are %d in inventory found in section: %c and your customers gave it an average review of %d%%!", applePrice, appleQuantity, appleLocation, appleReviewDisplay);

}