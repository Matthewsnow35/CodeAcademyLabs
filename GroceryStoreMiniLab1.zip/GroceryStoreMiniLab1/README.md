# Grocery Store C Lab

This project is a simple C program simulating the tracking of information for a specific product in a grocery store: **apples**. We'll create and assign basic variables to represent product details like inventory, price, reviews, and location.

## Project Overview
In this lab, we will:
- Declare variables to store product information.
- Assign values to these variables.
- Use constants to secure certain data fields.
- Perform casting for display purposes.

## Steps

### 1. Creating Variables
- **`appleQuantity`**: An integer to store the inventory quantity of apples.
- **`applePrice`**: A `float` or `double` to store the price of apples.
- **`appleReview`**: A `float` or `double` to store the average customer review as a decimal.
- **`appleReviewDisplay`**: An integer to display a rounded version of the customer review score.
- **`appleLocation`**: A `char` to represent the store location of apples (e.g., aisle "F").

### 2. Assigning Values
- Assign `1.49` to `applePrice` and `'F'` to `appleLocation` at declaration.
- After declaration, set `appleQuantity` to `23` and `appleReview` to `82.5`.

### 3. Setting Constants
- Make `appleLocation` a constant to prevent changes to its value.

### 4. Casting for Display
- Cast `appleReview` to an integer and assign it to `appleReviewDisplay` for display purposes.

### 5. Testing
Run the program to verify that all values are correctly assigned and displa